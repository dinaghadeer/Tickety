import 'package:flutter/material.dart';
import 'ticket_details_screen.dart'; 

class TicketsListScreen extends StatelessWidget {
  TicketsListScreen({super.key});

  final List<Map<String, dynamic>> tickets = [
    {'name': 'Al-Ahly vs Zamalek Match', 'qty': 2, 'image': 'Al-AhlyvsZamalek.jpg'},
    {'name': 'Amr Diab Concert', 'qty': 1, 'image': 'AmrDiabConcert.jpg'},
    {'name': 'Cairo Book Fair', 'qty': 4, 'image': 'CairoInternationalBookFair.jpeg'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My EasyTickets'),
        backgroundColor: Colors.deepPurple,
      ),
      body: ListView.builder(
        itemCount: tickets.length,
        itemBuilder: (context, index) {
          final ticket = tickets[index];
          return Card(
            margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            child: ListTile(

              leading: const Icon(Icons.confirmation_number_rounded, color: Colors.deepPurple), 
              title: Text(ticket['name']!),
              subtitle: Text('Tickets: ${ticket['qty']}'),
              trailing: const Icon(Icons.arrow_forward_ios),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => TicketDetailsScreen(
                      eventName: ticket['name']!,
                      quantity: ticket['qty']!,
                    ),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}