import 'package:flutter/material.dart';
import 'tickets_list_screen.dart'; 

void main() {
  runApp(const FlutterTicketApp());
}

class FlutterTicketApp extends StatelessWidget {
  const FlutterTicketApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'EasyTickets Viewer',
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: TicketsListScreen(), 
    );
  }
}